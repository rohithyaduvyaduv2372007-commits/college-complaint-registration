</main>

<footer class="site-footer">
    <div class="container footer-content">
        <div>
            <strong>Complaint Portal</strong>
            <p>Student Complaint Management</p>
        </div>
        <div>
            <p>&copy; <?php echo date("Y"); ?> All rights reserved.</p>
        </div>
    </div>
</footer>

<script src="<?php echo $basePath ?? ''; ?>js/validation.js"></script>
</body>
</html>