<?php

require_once "config/database.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$pageTitle = "Complaint Submitted - Complaint portal";

$category = trim($_POST["category"] ?? "");
$subject = trim($_POST["subject"] ?? "");
$priority = trim($_POST["priority"] ?? "");
$description = trim($_POST["description"] ?? "");

if ($category === "" || $subject === "" || $priority === "" || $description === "") {
    header("Location: complaint.php");
    exit();
}

$userId = $_SESSION["user_id"];

$referenceId = "CC-" . date("Ymd") . "-" . random_int(1000, 9999);

try {

    $sql = "INSERT INTO complaints
            (user_id, reference_id, category, subject, description, priority, status, admin_response, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 'Pending', NULL, NOW())";

    $stmt = $conn->prepare($sql);

    $stmt->execute([
        $userId,
        $referenceId,
        $category,
        $subject,
        $description,
        $priority
    ]);

} catch (PDOException $e) {

    die("Unable to submit complaint. Please try again.");

}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title><?php echo htmlspecialchars($pageTitle); ?></title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

</head>

<body>

<header class="site-header">

    <div class="container header-content">

        <div class="brand">

            <div class="brand-icon">
                CC
            </div>

            <div>
                <h1>Complaint portal</h1>

                <p>
                    College Complaint Management System
                </p>
            </div>

        </div>

        <a
            href="dashboard.php"
            class="header-login"
        >
            Dashboard
        </a>

    </div>

</header>


<main>

    <section class="form-section">

        <div class="container">

            <div class="form-card">

                <div class="section-heading">

                    <span>Complaint Submitted</span>

                    <h2>
                        Your Complaint Has Been Received
                    </h2>

                    <p>
                        Please keep your complaint reference ID
                        for future tracking.
                    </p>

                </div>


                <div class="reference-box">

                    <span>
                        Complaint Reference ID
                    </span>

                    <strong>
                        <?php echo htmlspecialchars($referenceId); ?>
                    </strong>

                </div>


                <div class="complaint-summary">

                    <div>
                        <strong>Category</strong>

                        <p>
                            <?php echo htmlspecialchars($category); ?>
                        </p>
                    </div>


                    <div>
                        <strong>Subject</strong>

                        <p>
                            <?php echo htmlspecialchars($subject); ?>
                        </p>
                    </div>


                    <div>
                        <strong>Priority</strong>

                        <p>
                            <?php echo htmlspecialchars($priority); ?>
                        </p>
                    </div>


                    <div>
                        <strong>Status</strong>

                        <p>
                            Pending
                        </p>
                    </div>

                </div>


                <div class="form-actions">

                    <a
                        href="complaint.php"
                        class="secondary-button"
                    >
                        Submit Another
                    </a>


                    <a
                        href="dashboard.php"
                        class="primary-button"
                    >
                        Go to Dashboard
                    </a>

                </div>

            </div>

        </div>

    </section>

</main>


<footer class="site-footer">

    <div class="container footer-content">

        <div>

            <strong>Complaint portal</strong>

            <p>
                College Complaint Management System
            </p>

        </div>


        <p>
            &copy; <?php echo date("Y"); ?>
            Student Complaint Management
        </p>

    </div>

</footer>

<script src="js/validation.js"></script>

</body>

</html>