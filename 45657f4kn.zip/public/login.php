<?php

require_once "config/database.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = "Login - complaint portal ";
$message = "";
$messageType = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($email === "" || $password === "") {

        $message = "Please enter your email and password.";
        $messageType = "error";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $message = "Please enter a valid email address.";
        $messageType = "error";

    } else {

        try {

            $sql = "SELECT id, name, email, password, role
                    FROM users
                    WHERE email = ?
                    LIMIT 1";

            $stmt = $conn->prepare($sql);
            $stmt->execute([$email]);

            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user["password"])) {

                session_regenerate_id(true);

                $_SESSION["user_id"] = $user["id"];
                $_SESSION["name"] = $user["name"];
                $_SESSION["email"] = $user["email"];
                $_SESSION["role"] = $user["role"];

                if ($user["role"] === "admin") {
                    header("Location: admin/dashboard.php");
                    exit();
                }

                header("Location: dashboard.php");
                exit();

            } else {

                $message = "Invalid email or password.";
                $messageType = "error";
            }

        } catch (PDOException $e) {

            $message = "Unable to login. Please try again.";
            $messageType = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<header class="site-header">

    <div class="container header-content">

        <div class="brand">

            <div class="brand-icon">CC</div>

            <div>
                <h1>Complaint portal</h1>
                <p>College Complaint Management System</p>
            </div>

        </div>

        <a href="index.php" class="header-login">Home</a>

    </div>

</header>

<main>

<section class="form-section">

    <div class="container">

        <div class="form-card">

            <div class="section-heading">
                <span>Complaint  portal Login</span>

                <h2>Welcome Back</h2>

                <p>
                    Login to access your Complaint portal account.
                </p>
            </div>

            <?php if ($message !== ""): ?>

                <div class="form-message <?php echo htmlspecialchars($messageType); ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>

            <?php endif; ?>

            <form method="POST" action="login.php">

                <div class="form-group">

                    <label for="email">
                        Email Address
                    </label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="Enter your email address"
                        required
                    >

                </div>

                <div class="form-group">

                    <label for="password">
                        Password
                    </label>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Enter your password"
                        required
                    >

                </div>

                <button
                    type="submit"
                    class="primary-button form-button">
                    Login
                </button>

            </form>

            <p class="form-footer">

                Don't have an account?

                <a href="register.php">
                    Register here
                </a>

            </p>

        </div>

    </div>

</section>

</main>

<footer class="site-footer">

    <div class="container footer-content">

        <div>
            <strong>Complaint portal</strong>
            <p>College Complaint Management System</p>
        </div>

        <p>
            &copy; <?php echo date("Y"); ?> student complaint management
        </p>

    </div>

</footer>

</body>
</html>