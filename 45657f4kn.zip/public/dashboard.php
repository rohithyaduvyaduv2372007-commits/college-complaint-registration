<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$userName = $_SESSION["name"] ?? "Student";
$pageTitle = "Dashboard - Complaint portal";

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title><?php echo htmlspecialchars($pageTitle); ?></title>

    <link rel="stylesheet" href="css/style.css">

</head>

<body>

<header class="site-header">

    <div class="container header-content">

        <div class="brand">

            <div class="brand-icon">CC</div>

            <div>
                <h1>Complaint portal</h1>
                <p>College Complaint Management System</p>
            </div>

        </div>

        <nav>

            <a href="dashboard.php">
                Dashboard
            </a>

            <a href="logout.php">
                Logout
            </a>

        </nav>

    </div>

</header>

<main>

<section class="form-section">

    <div class="container">

        <div class="section-heading">

            <span>Student Dashboard</span>

            <h2>
                Welcome, <?php echo htmlspecialchars($userName); ?>!
            </h2>

            <p>
                Manage your college complaints from one place.
            </p>

        </div>


        <div class="dashboard-cards">


            <div class="card">

                <h3>Create Complaint</h3>

                <p>
                    Submit a new complaint to the college administration.
                </p>

                <a href="complaint.php"
                   class="primary-button">
                    Create Complaint
                </a>

            </div>


            <div class="card">

                <h3>View Complaints</h3>

                <p>
                    View your complaints and check their current status.
                </p>

                <a href="view_complaint.php"
                   class="primary-button">
                    View Complaints
                </a>

            </div>


        </div>

    </div>

</section>

</main>

<footer class="site-footer">

    <div class="container footer-content">

        <div>
            <strong>Complaint portal</strong>
            <p>College Complaint Management System</p>
        </div>

        <p>
            &copy; <?php echo date("Y"); ?> Student Complaint Management
        </p>

    </div>

</footer>

</body>

</html>