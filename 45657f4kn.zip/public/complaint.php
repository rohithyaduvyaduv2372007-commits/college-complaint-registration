<?php
$pageTitle = "Submit Complaint - Complaint portal";
$message = "";
$messageType = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $category = trim($_POST["category"] ?? "");
    $subject = trim($_POST["subject"] ?? "");
    $priority = trim($_POST["priority"] ?? "");
    $description = trim($_POST["description"] ?? "");

    if ($category == "" || $subject == "" || $priority == "" || $description == "") {
        $message = "Please fill in all complaint details.";
        $messageType = "error";
    } else {
        $message = "Complaint details received successfully.";
        $messageType = "success";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<header class="site-header">
    <div class="container header-content">

        <div class="brand">
            <div class="brand-icon">CC</div>

            <div>
                <h1>Complaint portal</portal></h1>
                <p>College Complaint Management System</p>
            </div>
        </div>

        <a href="dashboard.php" class="header-login">Dashboard</a>

    </div>
</header>


<main>

    <section class="form-section">

        <div class="container">

            <div class="form-card">

                <div class="section-heading">
                    <span>Student Complaint</span>

                    <h2>Submit a Complaint</h2>

                    <p>
                        Provide the details of your issue so that
                        the administration can review it.
                    </p>
                </div>


                <?php if ($message != ""): ?>

                    <div class="form-message <?php echo $messageType; ?>">
                        <?php echo htmlspecialchars($message); ?>
                    </div>

                <?php endif; ?>


                <form method="POST" action="submit_complaint.php">

                    <div class="form-group">

                        <label for="category">
                            Complaint Category
                        </label>

                        <select id="category" name="category" required>

                            <option value="">
                                Select Category
                            </option>

                            <option value="Hostel">
                                Hostel
                            </option>

                            <option value="Transport">
                                Transport
                            </option>

                            <option value="Canteen">
                                Canteen
                            </option>

                            <option value="Academics">
                                Academics
                            </option>

                            <option value="Infrastructure">
                                Infrastructure
                            </option>

                            <option value="Examination">
                                Examination
                            </option>

                            <option value="Other">
                                Other
                            </option>

                        </select>

                    </div>


                    <div class="form-group">

                        <label for="subject">
                            Complaint Subject
                        </label>

                        <input
                            type="text"
                            id="subject"
                            name="subject"
                            placeholder="Enter complaint subject"
                            required
                        >

                    </div>


                    <div class="form-group">

                        <label for="priority">
                            Priority
                        </label>

                        <select id="priority" name="priority" required>

                            <option value="">
                                Select Priority
                            </option>

                            <option value="Low">
                                Low
                            </option>

                            <option value="Medium">
                                Medium
                            </option>

                            <option value="High">
                                High
                            </option>

                        </select>

                    </div>


                    <div class="form-group">

                        <label for="description">
                            Complaint Description
                        </label>

                        <textarea
                            id="description"
                            name="description"
                            rows="6"
                            placeholder="Describe your complaint clearly..."
                            required
                        ></textarea>

                    </div>


                    <button
                        type="submit"
                        class="primary-button form-button"
                    >
                        Submit Complaint
                    </button>

                </form>


                <p class="form-footer">

                    <a href="dashboard.php">
                        ← Back to Dashboard
                    </a>

                </p>

            </div>

        </div>

    </section>

</main>


<footer class="site-footer">

    <div class="container footer-content">

        <div>
            <strong>Complaint portal</strong>

            <p>
                College Complaint Management System
            </p>
        </div>


        <p>
            &copy; <?php echo date("Y"); ?>
            Student Complaint Management
        </p>

    </div>

</footer>
<script src="js/validation.js"></script>
</body>
</html>