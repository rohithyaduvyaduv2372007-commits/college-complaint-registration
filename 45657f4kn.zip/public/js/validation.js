document.addEventListener("DOMContentLoaded", function () {

    const forms = document.querySelectorAll("form");

    forms.forEach(function (form) {

        form.addEventListener("submit", function (event) {

            const requiredFields =
                form.querySelectorAll("[required]");

            let valid = true;

            requiredFields.forEach(function (field) {

                if (field.value.trim() === "") {

                    valid = false;

                    field.style.borderColor = "#dc2626";

                } else {

                    field.style.borderColor = "";

                }

            });


            const password =
                form.querySelector("#password");

            const confirmPassword =
                form.querySelector("#confirm_password");


            if (
                password &&
                confirmPassword &&
                password.value !== confirmPassword.value
            ) {

                valid = false;

                confirmPassword.style.borderColor = "#dc2626";

                alert("Passwords do not match.");

            }


            if (!valid) {

                event.preventDefault();

                if (
                    !password ||
                    !confirmPassword ||
                    password.value === confirmPassword.value
                ) {
                    alert("Please fill in all required fields.");
                }

            }

        });

    });

});