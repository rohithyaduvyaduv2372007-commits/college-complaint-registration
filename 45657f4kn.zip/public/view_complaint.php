<?php

require_once "config/database.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION["user_id"];
$pageTitle = "My Complaints - Complaint portal";

$complaints = [];
$error = "";

try {

    $sql = "SELECT
                id,
                reference_id,
                category,
                subject,
                description,
                priority,
                status,
                admin_response,
                created_at
            FROM complaints
            WHERE user_id = ?
            ORDER BY created_at DESC";

    $stmt = $conn->prepare($sql);
    $stmt->execute([$userId]);

    $complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    $error = "Unable to load complaints.";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title><?php echo htmlspecialchars($pageTitle); ?></title>

    <link rel="stylesheet" href="css/style.css">

</head>

<body>

<header class="site-header">

    <div class="container header-content">

        <div class="brand">

            <div class="brand-icon">CC</div>

            <div>
                <h1>CampusCare</h1>
                <p>College Complaint Management System</p>
            </div>

        </div>

        <nav>

            <a href="dashboard.php">
                Dashboard
            </a>

            <a href="logout.php">
                Logout
            </a>

        </nav>

    </div>

</header>


<main>

<section class="form-section">

    <div class="container">

        <div class="section-heading">

            <span>Complaint Management</span>

            <h2>My Complaints</h2>

            <p>
                View your submitted complaints and their current status.
            </p>

        </div>


        <?php if ($error !== ""): ?>

            <div class="form-message error">
                <?php echo htmlspecialchars($error); ?>
            </div>

        <?php elseif (count($complaints) === 0): ?>

            <div class="card">

                <h3>No Complaints Found</h3>

                <p>
                    You have not submitted any complaints yet.
                </p>

                <a href="complaint.php"
                   class="primary-button">
                    Create Your First Complaint
                </a>

            </div>

        <?php else: ?>


            <div class="complaints-container">

                <?php foreach ($complaints as $complaint): ?>

                    <div class="card complaint-card">

                        <h3>
                            <?php
                            echo htmlspecialchars(
                                $complaint["subject"]
                            );
                            ?>
                        </h3>


                        <p>
                            <strong>Reference ID:</strong>

                            <?php
                            echo htmlspecialchars(
                                $complaint["reference_id"] ?? "N/A"
                            );
                            ?>
                        </p>


                        <p>
                            <strong>Category:</strong>

                            <?php
                            echo htmlspecialchars(
                                $complaint["category"]
                            );
                            ?>
                        </p>


                        <p>
                            <strong>Priority:</strong>

                            <?php
                            echo htmlspecialchars(
                                $complaint["priority"] ?? "N/A"
                            );
                            ?>
                        </p>


                        <p>
                            <strong>Description:</strong><br>

                            <?php
                            echo nl2br(
                                htmlspecialchars(
                                    $complaint["description"]
                                )
                            );
                            ?>
                        </p>


                        <p>
                            <strong>Status:</strong>

                            <?php
                            echo htmlspecialchars(
                                $complaint["status"]
                            );
                            ?>
                        </p>


                        <p>
                            <strong>Admin Response:</strong><br>

                            <?php

                            if (
                                !empty(
                                    $complaint["admin_response"]
                                )
                            ) {

                                echo nl2br(
                                    htmlspecialchars(
                                        $complaint["admin_response"]
                                    )
                                );

                            } else {

                                echo "No response yet.";

                            }

                            ?>

                        </p>


                        <p>
                            <strong>Submitted On:</strong>

                            <?php
                            echo htmlspecialchars(
                                $complaint["created_at"]
                            );
                            ?>
                        </p>

                    </div>

                <?php endforeach; ?>

            </div>


        <?php endif; ?>


    </div>

</section>

</main>


<footer class="site-footer">

    <div class="container footer-content">

        <div>

            <strong>Complaint portal</strong>

            <p>
                College Complaint Management System
            </p>

        </div>

        <p>
            &copy; <?php echo date("Y"); ?> Student Complaint Management
        </p>

    </div>

</footer>

</body>

</html>