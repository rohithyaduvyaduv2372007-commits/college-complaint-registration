<?php
require_once "config/database.php";

session_start();

$pageTitle = "Register - Complaint portal";
$message = "";
$messageType = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirmPassword = $_POST["confirm_password"] ?? "";

    if ($name == "" || $email == "" || $password == "" || $confirmPassword == "") {
        $message = "Please fill in all fields.";
        $messageType = "error";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Please enter a valid email address.";
        $messageType = "error";
    } elseif ($password != $confirmPassword) {
        $message = "Passwords do not match.";
        $messageType = "error";
    } else {

    try {

        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);

        if ($check->fetch()) {

            $message = "Email address is already registered.";
            $messageType = "error";

        } else {

            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare(
                "INSERT INTO users (name, email, password, role)
                 VALUES (?, ?, ?, 'student')"
            );

            $stmt->execute([
                $name,
                $email,
                $hashedPassword
            ]);

            $message = "Registration successful. You can now login.";
            $messageType = "success";
        }

    } catch (PDOException $e) {

        $message = "Registration failed. Please try again.";
        $messageType = "error";
    }
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>

    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="site-header">
    <div class="container header-content">

        <div class="brand">
            <div class="brand-icon">CC</div>

            <div>
                <h1>Complaint portal</h1>
                <p>College Complaint Management System</p>
            </div>
        </div>

        <a href="login.php" class="header-login">Login</a>

    </div>
</header>

<main>

    <section class="form-section">

        <div class="container">

            <div class="form-card">

                <div class="section-heading">
                    <span>Student Registration</span>
                    <h2>Create Your Complaint portal Account</h2>
                    <p>Register to submit and track your college complaints.</p>
                </div>

                <?php if ($message != ""): ?>
                    <div class="form-message <?php echo $messageType; ?>">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">

                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            placeholder="Enter your full name"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            placeholder="Enter your email address"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="password">Password</label>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Create a password"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="confirm_password">Confirm Password</label>
                        <input
                            type="password"
                            id="confirm_password"
                            name="confirm_password"
                            placeholder="Re-enter your password"
                            required
                        >
                    </div>

                    <button type="submit" class="primary-button form-button">
                        Create Account
                    </button>

                </form>

                <p class="form-footer">
                    Already have an account?
                    <a href="login.php">Login here</a>
                </p>

            </div>

        </div>

    </section>

</main>

<footer class="site-footer">
    <div class="container footer-content">

        <div>
            <strong>Complaint portal</strong>
            <p>College Complaint Management System</p>
        </div>

        <p>
            &copy; <?php echo date("Y"); ?> Student Complaint Management
        </p>

    </div>
</footer>
<script src="js/validation.js"></script>
</body>
</html>