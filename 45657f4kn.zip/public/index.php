<?php
session_start();
$pageTitle = "Home";
include "includes/header.php";
?>

<section class="hero-section">
    <div class="container hero-content">

        <div class="hero-text">
            <span class="welcome-badge">Student Complaint Portal</span>
            <h2>Raise a complaint. <span>Track it online.</span></h2>
            <p>
                Submit your complaint, get a reference ID, and check the status
                and the administration's response anytime.
            </p>
            <div class="hero-buttons">
                <a href="register.php" class="primary-button">Register</a>
                <a href="login.php" class="secondary-button">Login</a>
            </div>
        </div>

        <div class="hero-card">
            <h3>How it works</h3>
            <p>1. Register and log in</p>
            <p>2. Submit your complaint</p>
            <p>3. Track status until it is resolved</p>
            <div class="status-flow">
                <div class="status-item"><span class="status-dot pending"></span><span>Pending</span></div>
                <div class="status-line"></div>
                <div class="status-item"><span class="status-dot progress"></span><span>In Progress</span></div>
                <div class="status-line"></div>
                <div class="status-item"><span class="status-dot resolved"></span><span>Resolved</span></div>
            </div>
        </div>

    </div>
</section>

<?php include "includes/footer.php"; ?>